import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    config_file_path = os.path.join('/home/mustafa/moria1/src/moria_deneme/config', 'ros2_controllers.yaml')
    
    return LaunchDescription([
        Node(
            package='controller_manager',
            executable='ros2_control_node',
            name='controller_manager',
            output='screen',
            parameters=[config_file_path]
        ),
        Node(
            package='controller_manager',
            executable='spawner',
            name='joint_state_broadcaster_spawner',
            arguments=['joint_state_broadcaster'],
            output='screen'
        ),
        Node(
            package='controller_manager',
            executable='spawner',
            name='arm1_controller_spawner',
            arguments=['arm1_controller'],
            output='screen'
        ),
        Node(
            package='controller_manager',
            executable='spawner',
            name='arm2_controller_spawner',
            arguments=['arm2_controller'],
            output='screen'
        ),
        Node(
            package='controller_manager',
            executable='spawner',
            name='kafa_controller_spawner',
            arguments=['kafa_controller'],
            output='screen'
        ),
    ])

